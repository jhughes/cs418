#ifndef VECTOR_H
#define VECTOR_H
struct Vector3{
float x;
float y;
float z;
};
#endif
